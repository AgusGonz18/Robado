#include "checkpoints.h"

uint32_t sumar_c(uint32_t a,uint32_t b){
	return a + b; 
}
uint32_t restar_c(uint32_t a,uint32_t b){
	return a - b; 
}

/* Pueden programar alguna rutina auxiliar del checkpoint 2 acá */
